import torch
import torch.nn as nn
import torch.nn.functional as F

class SpectralGraphAttention(nn.Module):
    def __init__(self, in_channels, reduction=16, topk=8):
        super().__init__()
        self.C, self.topk = in_channels, topk
        self.project = nn.Sequential(
            nn.Conv2d(in_channels, in_channels//reduction, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels//reduction, in_channels, 1)
        )
        self.lambda_param = nn.Parameter(torch.tensor(1.0))

    def _build_laplacian(self, H, W, device, dtype):
        N = H * W
        idx = torch.arange(N, device=device)
        r, c = idx // W, idx % W
        rows, cols = [], []
        for dr, dc in [(-1,0), (1,0), (0,-1), (0,1)]:
            rr, cc = r + dr, c + dc
            m = (rr >= 0) & (rr < H) & (cc >= 0) & (cc < W)
            rows.append(idx[m])
            cols.append((rr * W + cc)[m])
        rows = torch.cat(rows)
        cols = torch.cat(cols)
        vals = torch.ones_like(rows, dtype=dtype)
        A = torch.sparse_coo_tensor(torch.stack([rows, cols]), vals, (N, N))
        deg = torch.sparse.sum(A, dim=1).to_dense()
        L = torch.diag(deg) - A.to_dense()
        return L.to(dtype)

    def forward(self, x):
        B, C, H, W = x.shape
        y = self.project(x).view(B, C, -1)  # [B,C,N]
        L = self._build_laplacian(H, W, x.device, x.dtype)
        e_vals, e_vecs = torch.linalg.eigh(L.float())
        e_vals, e_vecs = e_vals.to(x.dtype), e_vecs.to(x.dtype)
        V, Λ = e_vecs[:, :self.topk], e_vals[:self.topk]
        σ = torch.sigmoid(self.lambda_param * Λ)
        Vt_y = torch.einsum('nk,bcn->bck', V, y) * σ.view(1, 1, -1)
        out = torch.einsum('nk,bck->bcn', V, Vt_y)
        return out.view(B, C, H, W)

class OptimalTransportFusion(nn.Module):
    def __init__(self, in_channels, sinkhorn_iter=10, eps=0.1):
        super().__init__()
        self.niter, self.eps = sinkhorn_iter, eps
        self.fc = nn.Sequential(
            nn.Linear(1, in_channels//4), nn.ReLU(inplace=True),
            nn.Linear(in_channels//4, 1), nn.Sigmoid()
        )

    def sinkhorn(self, cost):
        B, N, M = cost.shape
        u = torch.zeros(B, N, device=cost.device, dtype=cost.dtype)
        v = torch.zeros(B, M, device=cost.device, dtype=cost.dtype)
        a = torch.full((B, N), 1/N, device=cost.device, dtype=cost.dtype)
        b = torch.full((B, M), 1/M, device=cost.device, dtype=cost.dtype)
        for _ in range(self.niter):
            u = self.eps * (torch.log(a) - 
                torch.logsumexp((-cost + u.unsqueeze(2) + v.unsqueeze(1))/self.eps, dim=2))
            v = self.eps * (torch.log(b) - 
                torch.logsumexp((-cost + u.unsqueeze(2) + v.unsqueeze(1))/self.eps, dim=1))
        return torch.exp((-cost + u.unsqueeze(2) + v.unsqueeze(1))/self.eps)

    def forward(self, local, global_attn):
        B, C, H, W = local.shape
        loc = local.view(B, C, -1).permute(0, 2, 1)
        glob = global_attn.view(B, C, -1).permute(0, 2, 1)
        cost = torch.cdist(loc, glob, p=2)
        P = self.sinkhorn(cost)
        wass = (P * cost).sum(dim=(1, 2), keepdim=True)
        α = self.fc(wass).view(B, 1, 1, 1)
        return α * local + (1 - α) * global_attn

class MorphoDynamicNet(nn.Module):
    def __init__(self, in_channels, groups=4, scales=(3,5,7),
                 reduction=16, topk=8, sink_iter=10, eps=0.1):
        super().__init__()
        self.graph = SpectralGraphAttention(in_channels, reduction, topk)
        self.ot    = OptimalTransportFusion(in_channels, sink_iter, eps)
        self.alpha = nn.Parameter(torch.tensor(0.1))
        self.act   = nn.SiLU()

    def forward(self, x):
        global_attn = self.graph(x)
        fused       = self.ot(x, global_attn)  
        return self.act(self.alpha * fused + x)


