import torch
import torch.nn as nn
import torch.nn.functional as F

# ----------------------------
# 1. 仅保留：李群参数化动态核生成
# ----------------------------
class DynamicKernelGenerator(nn.Module):
    def __init__(self, channels, groups, max_scale=7):
        super().__init__()
        assert channels % groups == 0
        self.C, self.G = channels, groups
        self.Cg = channels // groups
        self.K = max_scale

        self.net = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, channels//4, 1), nn.GELU(),
            nn.Conv2d(channels//4, groups*3, 1)
        )

        base = torch.zeros(groups, self.Cg, self.Cg, self.K, self.K)
        mid = self.K // 2
        for g in range(groups):
            for i in range(self.Cg):
                base[g, i, i, mid, mid] = 1.0
        self.register_buffer('base', base)

    def forward(self, x, scales):
        B, C, H, W = x.shape
        params = self.net(x)
        params = params.view(B, self.G, 3)
        ω, tx, ty = params.unbind(-1)

        xi = torch.zeros(B, self.G, 3, 3, device=x.device, dtype=torch.float32)
        xi[..., 0,1] = -ω.float()
        xi[..., 1,0] = ω.float()
        xi[..., 0,2] = tx.float()
        xi[..., 1,2] = ty.float()
        G_mat = torch.matrix_exp(xi).to(x.dtype)

        base = self.base.unsqueeze(0).expand(B, -1, -1, -1, -1, -1)
        base = base.reshape(B*self.G, self.Cg*self.Cg, self.K, self.K)

        aff = G_mat[..., :2, :].reshape(B*self.G, 2, 3)
        kernels = []
        for S in scales:
            grid = F.affine_grid(aff, (B*self.G, self.Cg*self.Cg, S, S), align_corners=False)
            sampled = F.grid_sample(base, grid, align_corners=False, padding_mode='border')
            kernels.append(sampled.view(B, self.G, self.Cg, self.Cg, S, S))

        outs = []
        for kern in kernels:
            S = kern.size(-1)
            pad = S // 2
            w = kern.reshape(B*self.G*self.Cg, self.Cg, S, S)
            y = F.conv2d(
                x.reshape(1, B*C, H, W),
                w,
                padding=pad,
                groups=B*self.G
            )
            outs.append(y.view(B, C, H, W))
        return torch.mean(torch.stack(outs, 0), 0)


# ----------------------------
# 2. MorphoDynamicNet（仅动态核）
# ----------------------------
class MorphoDynamicNet(nn.Module):
    def __init__(self, in_channels, groups=4, scales=(3,5,7),
                 reduction=16, topk=8, sink_iter=10, eps=0.1):
        super().__init__()
        self.kernel_gen = DynamicKernelGenerator(in_channels, groups, max_scale=max(scales))
        self.alpha      = nn.Parameter(torch.tensor(0.1))
        self.scales     = scales
        self.act        = nn.SiLU()

    def forward(self, x):
        local = self.kernel_gen(x, self.scales)
        return self.act(self.alpha * local + x)


