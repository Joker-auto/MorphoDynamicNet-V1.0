import torch
import torch.nn as nn
import torch.nn.functional as F

# ----------------------------
# 最优传输融合模块（只用这个）
# ----------------------------
class OptimalTransportFusion(nn.Module):
    def __init__(self, in_channels, sinkhorn_iter=10, eps=0.1):
        super().__init__()
        self.niter, self.eps = sinkhorn_iter, eps
        self.fc = nn.Sequential(
            nn.Linear(1, in_channels // 4), nn.ReLU(inplace=True),
            nn.Linear(in_channels // 4, 1), nn.Sigmoid()
        )

    def sinkhorn(self, cost):
        B, N, M = cost.shape
        u = torch.zeros(B, N, device=cost.device, dtype=cost.dtype)
        v = torch.zeros(B, M, device=cost.device, dtype=cost.dtype)
        a = torch.full((B, N), 1/N, device=cost.device, dtype=cost.dtype)
        b = torch.full((B, M), 1/M, device=cost.device, dtype=cost.dtype)

        for _ in range(self.niter):
            u = self.eps * (
                torch.log(a + 1e-8) -
                torch.logsumexp((-cost + u.unsqueeze(2) + v.unsqueeze(1)) / self.eps, dim=2)
            )
            v = self.eps * (
                torch.log(b + 1e-8) -
                torch.logsumexp((-cost + u.unsqueeze(2) + v.unsqueeze(1)) / self.eps, dim=1)
            )

        P = torch.exp((-cost + u.unsqueeze(2) + v.unsqueeze(1)) / self.eps)
        return P

    def forward(self, local, global_attn):
        B, C, H, W = local.shape
        loc = local.view(B, C, -1).permute(0, 2, 1)    # [B, N, C]
        glob = global_attn.view(B, C, -1).permute(0, 2, 1)  # [B, M, C]
        cost = torch.cdist(loc, glob, p=2)  # [B, N, M]

        P = self.sinkhorn(cost)
        wass = (P * cost).sum(dim=(1, 2), keepdim=True)  # Wasserstein distance
        alpha = self.fc(wass).view(B, 1, 1, 1)
        return alpha * local + (1 - alpha) * global_attn

class MorphoDynamicNet(nn.Module):
    def __init__(self, in_channels, groups=4, scales=(3,5,7),
                 reduction=16, topk=8, sink_iter=10, eps=0.1):
        super().__init__()
        self.ot = OptimalTransportFusion(in_channels, sink_iter, eps)
        self.act = nn.SiLU()

    def forward(self, x):
        local = x  # 使用输入作为局部特征
        global_attn = x.clone()  # 使用输入作为全局特征
        fused = self.ot(local, global_attn)
        return self.act(fused)


