import torch
import torch.nn as nn
import torch.nn.functional as F

class DynamicKernelGenerator(nn.Module):
    def __init__(self, channels, groups, max_scale=7):
        super().__init__()
        assert channels % groups == 0
        self.C, self.G = channels, groups
        self.Cg = channels // groups
        self.K = max_scale

        self.net = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, channels//4, 1), nn.GELU(),
            nn.Conv2d(channels//4, groups*3, 1)
        )
        base = torch.zeros(groups, self.Cg, self.Cg, self.K, self.K)
        mid = self.K//2
        for g in range(groups):
            for i in range(self.Cg):
                base[g, i, i, mid, mid] = 1.0
        self.register_buffer('base', base)

    def forward(self, x, scales):
        B, C, H, W = x.shape
        params = self.net(x)                   
        params = params.view(B, self.G, 3)
        ω, tx, ty = params.unbind(-1)

        xi = torch.zeros(B, self.G, 3, 3, device=x.device, dtype=torch.float32)
        xi[..., 0,1] = -ω.float()
        xi[..., 1,0] = ω.float()
        xi[..., 0,2] = tx.float()
        xi[..., 1,2] = ty.float()
        G_mat = torch.matrix_exp(xi).to(x.dtype)  

        base = self.base.unsqueeze(0).expand(B, -1, -1, -1, -1, -1)
        base = base.reshape(B*self.G, self.Cg*self.Cg, self.K, self.K)
        aff = G_mat[..., :2, :].reshape(B*self.G, 2, 3)
        kernels = []
        for S in scales:
            grid = F.affine_grid(aff, (B*self.G, self.Cg*self.Cg, S, S),
                                 align_corners=False)
            sampled = F.grid_sample(base, grid,
                                    align_corners=False,
                                    padding_mode='border')
            kernels.append(sampled.view(B, self.G, self.Cg, self.Cg, S, S))

        outs = []
        for kern in kernels:
            S = kern.size(-1)
            pad = S//2
            w = kern.reshape(B*self.G*self.Cg, self.Cg, S, S)
            y = F.conv2d(
                x.reshape(1, B*C, H, W),
                w,
                padding=pad,
                groups=B*self.G
            )
            outs.append(y.view(B, C, H, W))
        return torch.mean(torch.stack(outs, 0), 0)

class SpectralGraphAttention(nn.Module):
    def __init__(self, in_channels, reduction=16, topk=8):
        super().__init__()
        self.C, self.topk = in_channels, topk
        self.project = nn.Sequential(
            nn.Conv2d(in_channels, in_channels//reduction, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels//reduction, in_channels, 1)
        )
        self.lambda_param = nn.Parameter(torch.tensor(1.0))

    def _build_laplacian(self, H, W, device, dtype):
        N = H*W
        idx = torch.arange(N, device=device)
        r, c = idx//W, idx%W
        rows, cols = [], []
        for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
            rr, cc = r+dr, c+dc
            m = (rr>=0)&(rr<H)&(cc>=0)&(cc<W)
            rows.append(idx[m]); cols.append((rr*W+cc)[m])
        rows = torch.cat(rows); cols = torch.cat(cols)
        vals = torch.ones(rows.numel(), device=device)
        A = torch.sparse_coo_tensor(torch.stack([rows, cols]), vals, (N,N))
        deg = torch.sparse.sum(A,1).to_dense()
        L = torch.diag(deg) - A.to_dense()
        return L.to(dtype)

    def forward(self, x):
        B, C, H, W = x.shape
        y = self.project(x).view(B, C, -1)  # [B,C,N]
        L = self._build_laplacian(H, W, x.device, x.dtype)
        e_vals, e_vecs = torch.linalg.eigh(L.float())
        e_vals, e_vecs = e_vals.to(x.dtype), e_vecs.to(x.dtype)
        V, Λ = e_vecs[:, :self.topk], e_vals[:self.topk]
        σ = torch.sigmoid(self.lambda_param * Λ)
        Vt_y = torch.einsum('nk,bcn->bck', V, y) * σ.view(1,1,-1)
        out = torch.einsum('nk,bck->bcn', V, Vt_y)
        return out.view(B, C, H, W)

class OptimalTransportFusion(nn.Module):
    def __init__(self, in_channels, sinkhorn_iter=10, eps=0.1):
        super().__init__()
        self.niter, self.eps = sinkhorn_iter, eps
        self.fc = nn.Sequential(
            nn.Linear(1, in_channels//4), nn.ReLU(inplace=True),
            nn.Linear(in_channels//4, 1), nn.Sigmoid()
        )

    def sinkhorn(self, cost):
        B, N, M = cost.shape
        u = torch.zeros(B, N, device=cost.device, dtype=cost.dtype)
        v = torch.zeros(B, M, device=cost.device, dtype=cost.dtype)
        a = torch.full((B, N), 1/N, device=cost.device, dtype=cost.dtype)
        b = torch.full((B, M), 1/M, device=cost.device, dtype=cost.dtype)
        for _ in range(self.niter):
            u = self.eps*(torch.log(a) - 
                torch.logsumexp((-cost + u.unsqueeze(2) + v.unsqueeze(1))/self.eps, dim=2))
            v = self.eps*(torch.log(b) - 
                torch.logsumexp((-cost + u.unsqueeze(2) + v.unsqueeze(1))/self.eps, dim=1))
        return torch.exp((-cost + u.unsqueeze(2) + v.unsqueeze(1))/self.eps)

    def forward(self, local, global_attn):
        B, C, H, W = local.shape
        loc = local.view(B, C, -1).permute(0,2,1)
        glob = global_attn.view(B, C, -1).permute(0,2,1)
        cost = torch.cdist(loc, glob, p=2)
        P = self.sinkhorn(cost)
        wass = (P * cost).sum(dim=(1,2), keepdim=True)
        α = self.fc(wass).view(B,1,1,1)
        return α*local + (1-α)*global_attn

class MorphoDynamicNet(nn.Module):
    def __init__(self, in_channels, groups=4, scales=(3,5,7),
                 reduction=16, topk=8, sink_iter=10, eps=0.1):
        super().__init__()
        assert in_channels % groups == 0
        self.kernel_gen = DynamicKernelGenerator(in_channels, groups, max_scale=max(scales))
        self.graph      = SpectralGraphAttention(in_channels, reduction, topk)
        self.ot         = OptimalTransportFusion(in_channels, sink_iter, eps)
        self.alpha      = nn.Parameter(torch.tensor(0.1))
        self.scales     = scales
        self.act        = nn.SiLU()

    def forward(self, x):
        local       = self.kernel_gen(x, self.scales)
        global_attn = self.graph(x)
        fused       = self.ot(local, global_attn)
        return self.act(self.alpha * fused + x)


