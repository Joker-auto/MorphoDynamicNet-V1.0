# only_spectral.py

import torch
import torch.nn as nn

# ======= SpectralGraphAttention =======
class SpectralGraphAttention(nn.Module):
    def __init__(self, in_channels, reduction=16, topk=8):
        super().__init__()
        self.C, self.topk = in_channels, topk
        self.project = nn.Sequential(
            nn.Conv2d(in_channels, in_channels//reduction, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels//reduction, in_channels, 1)
        )
        self.lambda_param = nn.Parameter(torch.tensor(1.0))

    def _build_laplacian(self, H, W, device, dtype):
        N = H * W
        idx = torch.arange(N, device=device)
        r, c = idx // W, idx % W
        rows, cols = [], []
        for dr, dc in [(-1,0), (1,0), (0,-1), (0,1)]:
            rr, cc = r + dr, c + dc
            m = (rr>=0) & (rr<H) & (cc>=0) & (cc<W)
            rows.append(idx[m]); cols.append((rr*W+cc)[m])
        rows = torch.cat(rows); cols = torch.cat(cols)
        vals = torch.ones(rows.numel(), device=device)
        A = torch.sparse_coo_tensor(torch.stack([rows, cols]), vals, (N, N))
        deg = torch.sparse.sum(A, 1).to_dense()
        L = torch.diag(deg) - A.to_dense()
        return L.to(dtype)

    def forward(self, x):
        B, C, H, W = x.shape
        y = self.project(x).view(B, C, -1)        # [B,C,N]
        L = self._build_laplacian(H, W, x.device, x.dtype)
        # 特征分解在 FP32
        e_vals, e_vecs = torch.linalg.eigh(L.float())
        e_vals, e_vecs = e_vals.to(x.dtype), e_vecs.to(x.dtype)
        V, Λ = e_vecs[:, :self.topk], e_vals[:self.topk]
        σ = torch.sigmoid(self.lambda_param * Λ)
        Vt_y = torch.einsum('nk,bcn->bck', V, y) * σ.view(1,1,-1)
        out  = torch.einsum('nk,bck->bcn', V, Vt_y)
        return out.view(B, C, H, W)

# ======= Only Spectral Graph Net =======
class MorphoDynamicNet(nn.Module):
    def __init__(self, in_channels, groups=4, scales=(3,5,7),
                 reduction=16, topk=8, sink_iter=10, eps=0.1):
        super().__init__()
        self.graph = SpectralGraphAttention(in_channels, reduction, topk)
        self.alpha = nn.Parameter(torch.tensor(0.1))
        self.act   = nn.SiLU()

    def forward(self, x):
        global_attn = self.graph(x)  # 仅 Global 特征
        return self.act(self.alpha * global_attn + x)

